function a = albedo(clouds)

    a = (0.55 .* clouds) + 0.10;
    
    %% Wolken
%     
%     wolken difuse einstrahlung niedriger temp gradient
%     
%     feuchte luft- wolken [check}
%     
%     
%     weniger wolken- mehr konvektion
    

    
    %%
    % (100nm - 100um)  
%     CONST.absorb_spectrum_h2o * h2o
    
end